require(['config'], function () {
  require(['src/parsley'], function (Parsley) {
  });
});
